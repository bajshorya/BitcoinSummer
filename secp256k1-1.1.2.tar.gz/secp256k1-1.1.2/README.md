# Haskell bindings for secp256k1

This project contains Haskell bindings for the [secp256k1](https://github.com/bitcoin-core/secp256k1) library from the Bitcoin Core project.
