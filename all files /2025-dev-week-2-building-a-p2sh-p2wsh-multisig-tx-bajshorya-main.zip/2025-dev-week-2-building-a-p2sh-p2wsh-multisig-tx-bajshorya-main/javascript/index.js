function main() {
    // Write your code here.
}

main();