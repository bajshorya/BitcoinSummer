fn main() {
    // Write your code here
}
