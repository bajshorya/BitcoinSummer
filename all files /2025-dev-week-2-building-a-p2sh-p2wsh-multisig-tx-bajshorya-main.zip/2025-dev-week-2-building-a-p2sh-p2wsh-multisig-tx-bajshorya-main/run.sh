# if you are using bash, uncomment the line below
# /bin/bash ./bash/run-bash.sh

# if you are using javascript, uncomment the line below
# /bin/bash ./javascript/run-javascript.sh

# if you are using python, uncomment the line below
# /bin/bash ./python/run-python.sh

# if you are using rust, uncomment the line below
# /bin/bash ./rust/run-rust.sh
