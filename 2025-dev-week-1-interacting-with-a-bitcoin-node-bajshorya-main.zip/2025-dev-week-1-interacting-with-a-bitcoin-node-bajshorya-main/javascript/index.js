const fs = require("fs");
const Client = require("bitcoin-core");

// RPC credentials and host
const RPC_USER = "alice";
const RPC_PASSWORD = "password";
const RPC_HOST = "http://127.0.0.1:18443";

// Connecting to the regtest network
const client = new Client({
  network: "regtest",
  username: RPC_USER,
  password: RPC_PASSWORD,
  host: RPC_HOST,
  port: 18443,
  ssl: {
    enabled: false,
    strict: false,
  },
  timeout: 30000,
});

// Setting up the wallet
async function setupWallet() {
  try {
    try {
      await client.command("unloadwallet", "testwallet"); // Unload wallet if already loaded
    } catch (unloadError) {}

    await new Promise((resolve) => setTimeout(resolve, 1000));

    try {
      await client.command("loadwallet", "testwallet"); // Load wallet if already exists
    } catch (loadError) {
      if (loadError.code === -18) {
        await client.command("createwallet", "testwallet"); // Create wallet if not exists
      } else {
        throw loadError;
      }
    }
    console.log("Wallet setup completed successfully");
  } catch (error) {
    console.error(
      "Error in wallet setup:",
      error,
      "Please make sure you have a wallet named testwallet in your regtest node"
    );
    throw error;
  }
}

// Generating a new address
async function generateAddress() {
  try {
    const response = await fetch(RPC_HOST, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain",
        Authorization:
          "Basic " +
          Buffer.from(`${RPC_USER}:${RPC_PASSWORD}`).toString("base64"),
      },
      body: JSON.stringify({
        jsonrpc: "1.0",
        id: "curltest",
        method: "getnewaddress",
        params: [],
      }),
    });

    const data = await response.json();
    if (data.error) {
      throw new Error(data.error.message);
    }

    const newAddress = data.result;
    console.log("New Bitcoin Address:", newAddress);
    return newAddress;
  } catch (error) {
    console.error("Error generating new address:", error);
    throw error;
  }
}

// Mining blocks
async function mineBlocks(address, blocks, maxTries = 1000000) {
  try {
    if (!address) throw new Error("Address is required.");
    if (!blocks || blocks <= 0) throw new Error("Invalid number of blocks.");

    const blockHashes = await client.command(
      "generatetoaddress",
      blocks,
      address,
      maxTries
    ); // Mine blocks to the address

    console.log(`Mined ${blocks} blocks to address ${address}`);
    return blockHashes;
  } catch (error) {
    console.error("Error mining blocks:", error);
  }
}

// async function createRawTransactionWithOpReturn(
//   recipientAddress,
//   amount,
//   feeRate = 21
// ) {
//   try {
//     const utxos = await client.command("listunspent");
//     if (utxos.length === 0) {
//       throw new Error("No UTXOs available to create the transaction.");
//     }

//     const opReturnScript = Buffer.from(
//       "6a" + Buffer.from("We are all Satoshi!!", "utf8").toString("hex"),
//       "hex"
//     );

//     const rawTx = await client.command(
//       "createrawtransaction",
//       [],
//       [{ [recipientAddress]: amount }, { data: opReturnScript.toString("hex") }]
//     );

//     const feeRateBTC = (feeRate / 100000000) * 1000;
//     const success = await client.command("settxfee", feeRateBTC);

//     if (!success) {
//       throw new Error("Failed to set transaction fee rate");
//     }

//     fs.writeFileSync("out.txt", txid);

//     return txid;
//   } catch (error) {
//     await client.command("settxfee", 0);
//     console.error("Error creating raw transaction with OP_RETURN:", error);
//     throw error;
//   }
// }
// Main function
async function createRawTransactionWithOpReturn(recipientAddress, amount) {
  try {
    const utxos = await client.command("listunspent");
    if (utxos.length === 0) {
      throw new Error("No UTXOs available to create the transaction.");
    }
    const utxo = utxos[0];

    const opReturnScript = Buffer.from("We are all Satoshi!!", "utf8");

    const rawTx = await client.command(
      "createrawtransaction",
      [
        {
          txid: utxo.txid,
          vout: utxo.vout,
        },
      ],
      {
        [recipientAddress]: amount,
        data: opReturnScript.toString("hex"),
      }
    );

    const fundedTx = await client.command("fundrawtransaction", rawTx, {
      fee_rate: 21.0,
    });

    console.log("Funded Transaction Details:", fundedTx);

    const signedTx = await client.command(
      "signrawtransactionwithwallet",
      fundedTx.hex
    );

    const txid = await client.command("sendrawtransaction", signedTx.hex);
    console.log("Transaction ID:", txid);

    const decodedTx = await client.command(
      "decoderawtransaction",
      fundedTx.hex
    );
    console.log("Decoded transaction:", decodedTx);

    // Log vsize and fee details
    console.log("Transaction vsize:", decodedTx.vsize);
    console.log("Calculated fee:", decodedTx.vsize * 21);
    console.log("Actual fee:", fundedTx.fee * -1 * 1e8);

    fs.writeFileSync("out.txt", txid);

    return txid;
  } catch (error) {
    console.error("Error creating raw transaction with OP_RETURN:", error);
    throw error;
  }
}





async function main() {
  try {
    await setupWallet();
    const address = await generateAddress();
    if (address) {
      console.log("\n--- Mining Maturity Blocks ---");
      await mineBlocks(address, 150);
      await new Promise((resolve) => setTimeout(resolve, 3000));
      const recipientAddress = "bcrt1qq2yshcmzdlznnpxx258xswqlmqcxjs4dssfxt2";
      const txid = await createRawTransactionWithOpReturn(
        recipientAddress,
        100.0
      );
      console.log("\n--- Sending Bitcoin with OP_RETURN ---");

      console.log("\n--- Transaction ID ---");
      console.log(txid);
    }
  } catch (error) {
    console.error("Main process error:", error);
    process.exit(1);
  }
}

// Run the main function
main().catch(console.error);
